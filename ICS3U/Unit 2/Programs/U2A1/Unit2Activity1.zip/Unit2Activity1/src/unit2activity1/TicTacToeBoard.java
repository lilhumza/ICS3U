package unit2activity1;

/**
 * @author Humza Khokhar
 * Date: July 22, 2019
 * Title: Tic Tac Toe Board
 * Purpose: Intro to NetBeans, Create TIC TAC TOE Board Using Keyboard Operators
 */

/**     
   *     System.out.println("        |       |       ");
   *     System.out.println("        |       |       ");
   *     System.out.println("        |       |       ");
   *     System.out.println("------------------------");
   *     System.out.println("        |       |       ");
   *     System.out.println("        |   X   |       ");
   *     System.out.println("        |       |       ");
   *     System.out.println("------------------------");
   *     System.out.println("        |       |       ");
   *     System.out.println("        |       |       ");
   *     System.out.println("        |       |       ");
   */  
public class TicTacToeBoard {

    public static void main(String[] args) {
        
        System.out.println("\t|\t|\t\n\t|\t|\t\n\t|\t|\t\n------------------------\n\t|\t|\t\n\t|   X   |\t\n\t|\t|\t\n------------------------\n\t|\t|\t\n\t|\t|\t\n\t|\t|\t\n");
        //Tic Tac Toe Board using using Keyboard functions for tabs and new lines
 
  
        
    }
    
}
