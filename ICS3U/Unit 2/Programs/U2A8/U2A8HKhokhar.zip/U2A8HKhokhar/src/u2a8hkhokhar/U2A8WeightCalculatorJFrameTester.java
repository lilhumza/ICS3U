package u2a8hkhokhar;
import javax.swing.JFrame;

/**
 * @author Humza Khokhar
 * Date: July 30
 * Program: Ideal Weight Calculator
 * Purpose: Summative Evaluation on GUI, Math Operators
 */
public class U2A8WeightCalculatorJFrameTester {

    public static void main(String[] args) {
        // TODO code application logic here
        U2A8WeightCalculator  myFrame = new U2A8WeightCalculator (); // create LabelFrame
        myFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        myFrame.setSize( 750,750 ); // set frame size
        myFrame.setVisible( true ); // display frame
        
    }
    
}
